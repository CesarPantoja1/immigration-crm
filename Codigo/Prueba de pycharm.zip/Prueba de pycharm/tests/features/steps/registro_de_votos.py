from behave import *
from sources.sistema_electoral import SistemaElectoral
from sources.votante import Votante

@given("que el proceso de elección de decano de la FIS está activo")
def step_sistema_votacion_activo(context):
    context.sistema_electoral = SistemaElectoral("Decano FIS")
    context.sistema_electoral.activar_proceso_eleccion()

@given("el votante esta autorizado para votar")
def step_votante_autorizado(context):
    context.votante = Votante(cedula="12345", nombre="Juan Naranjo", correo="juan.naranjo01@epn.edu.ec")
    context.sistema_electoral.registrar_votante(context.votante)
    context.sistema_electoral.esta_autorizado(context.votante, autorizado=True)

@when("el votante confirma su elección")
def step_confirmar_eleccion(context):
    context.sistema_electoral.registrar_voto(context.votante, opcion="Candidato A")

@then("la opción seleccionada incrementa en un voto su total")
def step_incrementar_total_voto(context):
   ##context.sistema_electoral.aumentar_voto("Candidato A")
    total = context.sistema_electoral.total_votos("Candidato A")
    assert total == 1, f"Se esperaba 1 voto, pero se obtuvo {total}"

@then("el votante ya no esta autorizado para votar de nuevo")
def step_verificar_autorizacion(context):
    ##context.votante.quitar_autorizacion()
    ##assert context.votante.esta_autorizado() is False, "El votante sigue autorizado para votar"
    estado_autorizacion = context.votante.autorizado
    assert estado_autorizacion is False, f"Se esperaba que el votante no este autorizado"

@then("el sistema envía la confirmación de voto al correo de voto al correo electrónico del votante")
def step_impl (context):
    enviados = context.sistema_electoral.revisar_notificaciones_enviadas()
    assert context.votante.correo in enviados, (
        f"No se registró envío a {context.votante.correo}"
    )