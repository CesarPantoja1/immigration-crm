from sources.votante import Votante

class SistemaElectoral:
    def __init__(self, nombre_eleccion):
        self.nombre = nombre_eleccion
        self.activa = False
        self.conteo = {"Candidato A": 0, "Candidato B": 0}
        self.notificaciones_enviadas: list[str] = []
        self.padron = {}

    def activar_proceso_eleccion(self):
        self.activa = True

    # ==== Registro votante ====
    def registrar_votante(self, votante: Votante):
        self.padron[votante.cedula] = votante

    def esta_autorizado(self, votante: Votante, autorizado):
        votante.esta_autorizado(autorizado)

    def registrar_voto(self, votante: Votante, opcion):
        if not self.activa:
            print("El proceso de elección no está activo.")
            return
        elif not votante.autorizado:
            print("El votante no está autorizado para votar.")
            return
        # Registrar el voto
        self.conteo[opcion] += 1
        # Quitar autorización para votar de nuevo
        votante.esta_autorizado(False)
        # Enviar confirmación
        self.enviar_confirmacion_voto(votante)


    def enviar_confirmacion_voto(self, votante: Votante):
        self.notificaciones_enviadas.append(votante.correo)


    def total_votos(self, opcion):
        return self.conteo.get(opcion, 0)

    def revisar_notificaciones_enviadas(self):
        return self.notificaciones_enviadas