class Votante:
    def __init__(self, cedula, nombre, correo):
        self.cedula = cedula
        self.nombre = nombre
        self.correo = correo
        self.autorizado = False

    def esta_autorizado(self, autorizado):
        self.autorizado = autorizado