**Sistema de Pedidos para Pizzería**

**Vision**:
Atraer clientes a los que les gustan las pizzas personalizadas 

**Objetivos del negocio:**
Facilitar a los clientes realizar pedidos de pizzas de forma virtual

**Capacidades:**
1. Armar pedido de pizzas personalizadas
2. Gestionar costos de los pedidos

**Características:**
1. Armar pizzas de diferentes tamaños y con varios ingredientes diferentes
2. Establecer el costo final del pedido