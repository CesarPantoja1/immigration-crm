from behave import *
from Sources.Cliente import Cliente

@step('el cliente "{nombre_cliente}" inicia un nuevo pedido')
def step_impl(context, nombre_cliente:str):
    context.cliente = Cliente(nombre_cliente)