class Cliente:
    def __init__(self, nombre_cliente:str):
        self.nombre_cliente = nombre_cliente
    